﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TreeExample
{
    class Tree
    {
        Node root = null;

        public void AddNonRec(int val)
        {
            if (root == null)
            {
                root = new Node(val);
            }else
            {
                Node tmp =root;
          back: if(tmp.val<val)
                {
                    if(tmp.right!=null)
                    {
                        tmp = tmp.right;
                        goto back;
                    }else
                    {
                        tmp.right = new Node(val);
                    }
                }
                else  if (tmp.val > val)
                    {
                        if (tmp.left != null)
                        {
                            tmp = tmp.left;
                            goto back;
                        }
                        else
                        {
                            tmp.left = new Node(val);
                        }
                    }
          else
                {
                    Console.WriteLine("Number exists");
                }

            }
        }
        public void Add(int val) {
            if (root == null)
            {
                root = new Node(val);
            }else
            {
                AddValue(val, root);
            }

        }
        private void AddValue(int val, Node x)
        {
            if(x.val<val)
            {
                if (x.right != null)
                    AddValue(val, x.right);
                else
                {
                    x.right = new Node(val);
                }
            }
            else if (x.val > val)
            {
                if (x.left != null)
                    AddValue(val, x.left);
                else
                {
                    x.left = new Node(val);
                }
            }else
            {
                Console.WriteLine("Number exists");
            }
        }
        //public bool Contains(int val) {...}

        public IEnumerator<int> GetEnumerator()
        {
            return root.GetEnumerator();
        }
    }

}
