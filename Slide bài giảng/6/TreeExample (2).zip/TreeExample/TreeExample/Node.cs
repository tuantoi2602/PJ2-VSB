﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TreeExample
{
    class Node
    {
        public int val;
        public Node left, right;

        public Node(int x) { val = x; left = null; right = null; }

        public IEnumerator<int> GetEnumerator()
        {
            if (left != null)
                foreach (int x in left) yield return x;
            yield return val;
            if (right != null)
                foreach (int x in right) yield return x;
        }
    }

}
