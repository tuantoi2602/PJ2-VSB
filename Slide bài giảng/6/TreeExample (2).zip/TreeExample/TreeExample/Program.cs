﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TreeExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Tree tr = new Tree();
            //tr.Add(10);
            //tr.Add(20);
            //tr.Add(30);
            //tr.Add(1);

            tr.AddNonRec(10);
            tr.AddNonRec(20);
            tr.AddNonRec(30);
            tr.AddNonRec(1);

            foreach (int item in tr)
            {
                Console.WriteLine(item);
            }
        }
    }
}
