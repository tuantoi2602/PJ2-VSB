﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnumeratorTest
{
    public class MyArray
    {
        private int []arrayLocal;
        private int position;
        public MyArray(int x)
        {
            arrayLocal = new int[x];
            position =0;
        }
        public void Add(int x)
        {
            if (position != arrayLocal.Length)
            {
                arrayLocal[position] = x;
                position++;
            }
        }

        public IEnumerator<int> GetEnumerator()
        {
            for (int i = 0; i < position; i++)
            {
                yield return arrayLocal[i];
            }
        }
    }
}
