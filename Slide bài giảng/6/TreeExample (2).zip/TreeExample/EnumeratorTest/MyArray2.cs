﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnumeratorTest
{
    class MyArray2 : IEnumerable
    {
        private int[] arrayLocal;
        private int position;
        public MyArray2(int x)
        {
            arrayLocal = new int[x];
            position = 0;
        }
        public void Add(int x)
        {
            if (position != arrayLocal.Length)
            {
                arrayLocal[position] = x;
                position++;
            }
        }

        public IEnumerator GetEnumerator()
        {
            return new MyEnumerator(arrayLocal, position);
        }
        class MyEnumerator : IEnumerator
        {
            private int posLocal = -1;
            private int[] arrayLocal;
            private int position;
            public MyEnumerator(int[] arrTmp, int posTmp)
            {
                arrayLocal = arrTmp;
                position = posTmp;
            }
            public object Current { get { return arrayLocal[posLocal]; } }
            public bool MoveNext()
            {
                if (position != posLocal+1)
                {
                    posLocal++;
                    return true;
                }
                else
                    return false;
            }
            public void Reset() { posLocal = -1; }
        }

    }

}


