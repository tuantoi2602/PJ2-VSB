﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnumeratorTest
{
    class Program
    {
        static void Main(string[] args)
        {
            //MyArray temp = new MyArray(10);
            MyArray2 temp = new MyArray2(10);
            for (int i = 0; i < 6; i++)
            {
                temp.Add(i * 100);
            }

            foreach (int item in temp)
            {
                Console.WriteLine(item); 
            }
        }
    }
}
