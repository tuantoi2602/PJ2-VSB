﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MojeAdt2;

namespace TestStackQueue
{
    class Program
    {
        static void Main(string[] args)
        {
            MyStack1();
            Console.WriteLine();
            MyStack2();
            Console.WriteLine();
            MyQueue();
        }

        private static void MyStack1()
        {
            MyStack1<int> myStack1 = new MyStack1<int>(3);

            try
            {
                myStack1.Push(2);
                myStack1.Push(3);
                myStack1.Push(1);
                myStack1.Push(4);
            }
            catch (FullException<int> e)
            {
                Console.WriteLine("{0} - {1}", e.Message, e.Element);
            }

            foreach (int item in myStack1)
            {
                Console.WriteLine(item);
            }

            try
            {
                for (int i = 0; i < 4; i++)
                {
                    Console.WriteLine("{0}", myStack1.Pop());
                }
            }
            catch (EmptyException e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static void MyStack2()
        {
            MyStack2<string> myStack2 = new MyStack2<string>(3);

            try
            {
                myStack2.Push("s2");
                myStack2.Push("s3");
                myStack2.Push("s4");
                myStack2.Push("s5");
            }
            catch (FullException<string> e)
            {
                Console.WriteLine("{0} - {1}", e.Message, e.Element);
            }

            foreach (string item in myStack2)
            {
                Console.WriteLine(item);
            }

            try
            {
                for (int i = 0; i < 4; i++)
                {
                    Console.WriteLine("{0}", myStack2.Pop());
                }
            }
            catch (EmptyException e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static void MyQueue()
        {
            MyQueue<double> myQueue = new MyQueue<double>(3);

            try
            {
                myQueue.Enque(2);
                myQueue.Enque(3.5);
                myQueue.Enque(4);
                myQueue.Enque(5.3);
            }
            catch (FullException<double> e)
            {
                Console.WriteLine("{0} - {1}", e.Message, e.Element);
            }

            foreach (double item in myQueue)
            {
                Console.WriteLine(item);
            }

            try
            {
                for (int i = 0; i < 4; i++)
                {
                    Console.WriteLine("{0}", myQueue.Deque());
                }
            }
            catch (EmptyException e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
