﻿using System;
using System.Collections;
using System.Windows.Forms;
using MojeAdt2;


namespace AdtGui
{
    public partial class MainWindow : Form
    {
        readonly MyStack2<int> _z = new MyStack2<int>();
        readonly MyQueue<int> _f = new MyQueue<int>();

        public MainWindow()
        {
            InitializeComponent();
            removeStack.Enabled = !_z.IsEmpty;
            removeQueue.Enabled = !_f.IsEmpty;
            UpdateListBox(stackListBox, _z);
            UpdateListBox(queueListBox, _f);
        }

        private static void UpdateListBox(ListBox l, IEnumerable prvky)
        {
            l.Items.Clear();
            foreach (var i in prvky)
            {
                l.Items.Add(i);
            }
        }

        private void InsertStack_Click(object sender, EventArgs e)
        {
            try
            {
                var number = Int32.Parse(numberStacktextBox.Text);
                _z.Push(number);
                UpdateListBox(stackListBox, _z);
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message, @"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            removeStack.Enabled = true;
        }

        private void RemoveStack_Click(object sender, EventArgs e)
        {
            _z.Pop();
            removeStack.Enabled = !_z.IsEmpty;
            UpdateListBox(stackListBox, _z);
        }

        private void InsertQueue_Click(object sender, EventArgs e)
        {
            try
            {
                var number = Int32.Parse(numberQueuetextBox.Text);
                _f.Enque(number);
                UpdateListBox(queueListBox, _f);
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message, @"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            removeQueue.Enabled = true;


        }

        private void RemoveQueue_Click(object sender, EventArgs e)
        {
            _f.Deque();
            removeQueue.Enabled = !_f.IsEmpty;
            UpdateListBox(queueListBox, _f);
        }
    }
}
