﻿namespace AdtGui
{
    partial class MainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.stackListBox = new System.Windows.Forms.ListBox();
            this.VlozitZasobnik = new System.Windows.Forms.Button();
            this.removeStack = new System.Windows.Forms.Button();
            this.numberStacktextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.frontaGroupBox = new System.Windows.Forms.GroupBox();
            this.queueListBox = new System.Windows.Forms.ListBox();
            this.vlozitFronta = new System.Windows.Forms.Button();
            this.removeQueue = new System.Windows.Forms.Button();
            this.numberQueuetextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.frontaGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox1.Controls.Add(this.stackListBox);
            this.groupBox1.Controls.Add(this.VlozitZasobnik);
            this.groupBox1.Controls.Add(this.removeStack);
            this.groupBox1.Controls.Add(this.numberStacktextBox);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(175, 353);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Stack";
            // 
            // zasobnikListBox
            // 
            this.stackListBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.stackListBox.FormattingEnabled = true;
            this.stackListBox.Location = new System.Drawing.Point(14, 98);
            this.stackListBox.Name = "zasobnikListBox";
            this.stackListBox.Size = new System.Drawing.Size(146, 225);
            this.stackListBox.TabIndex = 4;
            // 
            // VlozitZasobnik
            // 
            this.VlozitZasobnik.Location = new System.Drawing.Point(104, 56);
            this.VlozitZasobnik.Name = "VlozitZasobnik";
            this.VlozitZasobnik.Size = new System.Drawing.Size(57, 22);
            this.VlozitZasobnik.TabIndex = 3;
            this.VlozitZasobnik.Text = "Insert";
            this.VlozitZasobnik.UseVisualStyleBackColor = true;
            this.VlozitZasobnik.Click += new System.EventHandler(this.InsertStack_Click);
            // 
            // odebratZasobnik
            // 
            this.removeStack.Location = new System.Drawing.Point(16, 56);
            this.removeStack.Name = "odebratZasobnik";
            this.removeStack.Size = new System.Drawing.Size(57, 22);
            this.removeStack.TabIndex = 2;
            this.removeStack.Text = "Remove";
            this.removeStack.UseVisualStyleBackColor = true;
            this.removeStack.Click += new System.EventHandler(this.RemoveStack_Click);
            // 
            // cisloZasobniktextBox
            // 
            this.numberStacktextBox.Location = new System.Drawing.Point(80, 19);
            this.numberStacktextBox.Name = "cisloZasobniktextBox";
            this.numberStacktextBox.Size = new System.Drawing.Size(81, 20);
            this.numberStacktextBox.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Number:";
            // 
            // frontaGroupBox
            // 
            this.frontaGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.frontaGroupBox.Controls.Add(this.queueListBox);
            this.frontaGroupBox.Controls.Add(this.vlozitFronta);
            this.frontaGroupBox.Controls.Add(this.removeQueue);
            this.frontaGroupBox.Controls.Add(this.numberQueuetextBox);
            this.frontaGroupBox.Controls.Add(this.label2);
            this.frontaGroupBox.Location = new System.Drawing.Point(449, 12);
            this.frontaGroupBox.Name = "frontaGroupBox";
            this.frontaGroupBox.Size = new System.Drawing.Size(175, 353);
            this.frontaGroupBox.TabIndex = 5;
            this.frontaGroupBox.TabStop = false;
            this.frontaGroupBox.Text = "Queue";
            // 
            // frontaListBox
            // 
            this.queueListBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.queueListBox.FormattingEnabled = true;
            this.queueListBox.Location = new System.Drawing.Point(14, 98);
            this.queueListBox.Name = "frontaListBox";
            this.queueListBox.Size = new System.Drawing.Size(146, 225);
            this.queueListBox.TabIndex = 4;
            // 
            // vlozitFronta
            // 
            this.vlozitFronta.Location = new System.Drawing.Point(104, 56);
            this.vlozitFronta.Name = "vlozitFronta";
            this.vlozitFronta.Size = new System.Drawing.Size(57, 22);
            this.vlozitFronta.TabIndex = 3;
            this.vlozitFronta.Text = "Insert";
            this.vlozitFronta.UseVisualStyleBackColor = true;
            this.vlozitFronta.Click += new System.EventHandler(this.InsertQueue_Click);
            // 
            // odebratFronta
            // 
            this.removeQueue.Location = new System.Drawing.Point(16, 56);
            this.removeQueue.Name = "odebratFronta";
            this.removeQueue.Size = new System.Drawing.Size(57, 22);
            this.removeQueue.TabIndex = 2;
            this.removeQueue.Text = "Remove";
            this.removeQueue.UseVisualStyleBackColor = true;
            this.removeQueue.Click += new System.EventHandler(this.RemoveQueue_Click);
            // 
            // cisloFrontatextBox
            // 
            this.numberQueuetextBox.Location = new System.Drawing.Point(80, 19);
            this.numberQueuetextBox.Name = "cisloFrontatextBox";
            this.numberQueuetextBox.Size = new System.Drawing.Size(81, 20);
            this.numberQueuetextBox.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Number:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(275, 21);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 30);
            this.button1.TabIndex = 6;
            this.button1.Text = "Test";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // HlavniOkno
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(636, 386);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.frontaGroupBox);
            this.Controls.Add(this.groupBox1);
            this.Name = "HlavniOkno";
            this.Text = "Stack and Queue";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.frontaGroupBox.ResumeLayout(false);
            this.frontaGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox stackListBox;
        private System.Windows.Forms.Button VlozitZasobnik;
        private System.Windows.Forms.Button removeStack;
        private System.Windows.Forms.TextBox numberStacktextBox;
        private System.Windows.Forms.GroupBox frontaGroupBox;
        private System.Windows.Forms.ListBox queueListBox;
        private System.Windows.Forms.Button vlozitFronta;
        private System.Windows.Forms.Button removeQueue;
        private System.Windows.Forms.TextBox numberQueuetextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
    }
}

