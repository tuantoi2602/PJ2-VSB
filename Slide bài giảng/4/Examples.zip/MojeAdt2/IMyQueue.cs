﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MojeAdt2
{
    public interface IMyQueue<T> : IEnumerable<T>
    {
        void Enque(T element); 
        T Deque();

        bool IsEmpty { get; }
        bool IsFull { get; }

        void Clear();        
    }
}
