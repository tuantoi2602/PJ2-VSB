﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MojeAdt2
{
    public class FullException<T> : ApplicationException
    {
        public T Element { get; private set; }

        public FullException(string message, T element)
            : base(message)
        {
            Element = element;
        }
    }
}
