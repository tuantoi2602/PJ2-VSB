﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace MojeAdt2
{
    public class MyQueue<T> : IMyQueue<T>
    {
        private readonly LinkedList<T> data = new LinkedList<T>();
        private readonly int maxSize;

        public MyQueue()
            : this(10)
        {
        }
        public MyQueue(int size)
        {
            data = new LinkedList<T>();
            maxSize = size;

        }

        public void Enque(T number)
        {
            if (!IsFull)
            {
                data.AddLast(number);
            }
            else
            {
                throw new FullException<T>("The queue is full!!!", number);
            }
        }

        public T Deque()
        {
            if (!IsEmpty)
            {
                var dataIn = data.First;
                data.RemoveFirst();
                return dataIn.Value;
            }
            throw new EmptyException("The queue is empty!!!");
        }

        public bool IsEmpty
        {
            get
            {
                return data.Count == 0;
            }
        }

        public bool IsFull
        {
            get
            {
                return data.Count == maxSize;
            }
        }

        public void Clear()
        {
            data.Clear();
        }

        public IEnumerator<T> GetEnumerator()
        {
            return data.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }

}


