﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace MojeAdt2
{
    public class MyStack1<T> : IMyStack<T>
    {
        private readonly T[] data;
        private int pointer;

        public MyStack1() : this(10) { }

        public MyStack1(int size)
        {
            data = new T[size];
            pointer = 0;
        }

        public void Push(T number)
        {
            if (!IsFull)
            {
                data[pointer++] = number;
            }
            else
            {
                throw new FullException<T>("The stack is full!!!", number);
            }
        }

        public T Pop()
        {
            if (!IsEmpty)
            {
                return data[--pointer];
            }
            throw new EmptyException("The stack is empty!!!");
        }

        public bool IsEmpty
        {
            get
            {
                return pointer == 0;
            }
        }

        public bool IsFull
        {
            get
            {
                return pointer == data.Length;
            }
        }

        public void Clear()
        {
            pointer = 0;
        }

        public IEnumerator GetEnumerator()
        {
            return new MyStack1Enumerator<T>(this);
        }

        IEnumerator<T> IEnumerable<T>.GetEnumerator()
        {
            return new MyStack1Enumerator<T>(this);
        }

        private class MyStack1Enumerator<O> : IEnumerator<O>
        {
            private readonly MyStack1<O> _zas;
            private int _enumUka;

            public MyStack1Enumerator(MyStack1<O> par)
            {
                _zas = par;
                Reset();
            }

            public bool MoveNext()
            {
                return --_enumUka >= 0;
            }

            public void Reset()
            {
                _enumUka = _zas.pointer;
            }

            object IEnumerator.Current
            {
                get
                {
                    return ((IEnumerator<O>)this).Current;
                }
            }

            O IEnumerator<O>.Current
            {
                get
                {
                    if (_zas != null)
                    {
                        return _zas.data[_enumUka];
                    }
                    throw new EmptyException("The stack is empty!!!");
                }
            }

            public void Dispose()
            {
            }
        }
    }
}