﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MojeAdt2
{
    public class EmptyException : ApplicationException
    {
   
        public EmptyException(string message)
            : base(message)
        {
        }
    }
}
