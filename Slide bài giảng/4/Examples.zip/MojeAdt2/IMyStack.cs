﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace MojeAdt2
{
    public interface IMyStack<T> : IEnumerable<T>
    {
        void Push(T element);
        T Pop();

        bool IsEmpty { get; }
        bool IsFull { get; }
        
        void Clear();        

    }
}
