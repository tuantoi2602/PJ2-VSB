﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace MojeAdt2
{
    public class MyStack2<T> : IMyStack<T>
    {
        private readonly T[] data;
        private int pointer;

        public MyStack2() : this(10) { }

        public MyStack2(int size)
        {
            data = new T[size];
            pointer = 0;
        }

        public void Push(T number)
        {
            if (!IsFull)
            {
                data[pointer++] = number;
            }
            else
            {
                throw new FullException<T>("The stack is full!!!", number);
            }
        }

        public T Pop()
        {
            if (!IsEmpty)
            {
                return data[--pointer];
            }
            throw new EmptyException("The stack is empty!!!");
        }

        public bool IsEmpty
        {
            get
            {
                return pointer == 0;
            }
        }

        public bool IsFull
        {
            get
            {
                return pointer == data.Length;
            }
        }

        public void Clear()
        {
            pointer = 0;
        }

        IEnumerator<T> IEnumerable<T>.GetEnumerator()
        {
            for (int i = pointer - 1; i >= 0; i--)
            {
                yield return data[i];
            }
        }

        public IEnumerator GetEnumerator()
        {
            return ((IEnumerable<T>)this).GetEnumerator();
        }

    }
}