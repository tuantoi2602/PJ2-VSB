﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Test;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Progress progress = new Progress();

            new Thread(() =>
            {
                Class1 class1 = new Class1();
                class1.myCurent = progress.SetCurent;
                class1.myMax = progress.SetMax;
                class1.MyRun();

                progress.Close();
            }).Start();

            progress.ShowDialog();
        }
    }
}
