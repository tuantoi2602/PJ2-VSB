﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Test
{
    public class Class1
    {
       public delegate void SetCurent(int x);
       public delegate void SetMax(int x);

        public SetCurent myCurent;

        public SetMax myMax;

        public void MyRun()
        {
            int max = 100;
            myMax(max);

            for (int i = 0; i < max; i++)
            {
                Thread.Sleep(100);
                myCurent(i);
            }
        }
        
    }
}
