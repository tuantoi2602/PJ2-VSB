﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Stack
{
    class MyStack:IMyStack
    {
        private int MAXOFELEMENTS = 10;
        private int[] elements;
        private int top;

        public MyStack()
        {
            elements = new int[MAXOFELEMENTS];
            top = -1;
        }

        public void Push(int i)
        {
            if (top != MAXOFELEMENTS - 1)
            {
                top++;
                elements[top] = i;
            }
        }

        public int Pop()
        {
            int result = 0;
            if (top != - 1)
            {                
                result =elements[top];
                top--;
            }
            else
            {
                result = -1;
            }
            return result;
        }

        public int Top()
        {
            if (IsEmpty())
                return -1;
            else
                return elements[top];
        }

        public bool IsEmpty()
        {
            if (top != -1)
                return false;
            return true;
        }

        public bool IsFull()
        {
            if (top == MAXOFELEMENTS - 1)
                return true;
            else
                return false;
        }
        public void Print()
        {
            Console.WriteLine("PRINT");
            for (int i = 0; i <= top; i++)
            {
                Console.WriteLine(elements[i]);
            }
        }
    }
}
