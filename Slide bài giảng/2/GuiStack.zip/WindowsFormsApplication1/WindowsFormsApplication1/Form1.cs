﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Stack;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        MyStack stack;
        public Form1()
        {
            InitializeComponent();
            stack = new MyStack();
        }

        private void bPush_Click(object sender, EventArgs e)
        {
            if (!stack.IsFull())
            {
                stack.Push(Convert.ToInt32(tbInputLeft.Text));
                listBox1.Items.Add(Convert.ToInt32(tbInputLeft.Text));
            }
            else
                tbRes.Text = "FULL";
        }

        private void bEmpty_Click(object sender, EventArgs e)
        {
            if (stack.IsEmpty())
                tbRes.Text = "true";
            else
                tbRes.Text = "false";
        }

        private void bFull_Click(object sender, EventArgs e)
        {
            if (stack.IsFull())
                tbRes.Text = "true";
            else
                tbRes.Text = "false";
        }

        private void bTop_Click(object sender, EventArgs e)
        {
            if (!stack.IsEmpty())
            {
                tbRes.Text = stack.Top().ToString();
            }
            else
            {
                tbRes.Text = "Empty";
            }
        }

        private void bPop_Click(object sender, EventArgs e)
        {
            if (!stack.IsEmpty())
            {
                tbRes.Text = stack.Pop().ToString();
                listBox1.Items.RemoveAt(listBox1.Items.Count-1);
            }
            else
            {
                tbRes.Text = "Empty";
            }
        }

    }
}
