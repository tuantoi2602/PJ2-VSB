﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bPush = new System.Windows.Forms.Button();
            this.tbInputLeft = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.bPop = new System.Windows.Forms.Button();
            this.tbRes = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.bTop = new System.Windows.Forms.Button();
            this.bEmpty = new System.Windows.Forms.Button();
            this.bFull = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bPush
            // 
            this.bPush.Location = new System.Drawing.Point(45, 69);
            this.bPush.Name = "bPush";
            this.bPush.Size = new System.Drawing.Size(75, 23);
            this.bPush.TabIndex = 0;
            this.bPush.Text = "Push";
            this.bPush.UseVisualStyleBackColor = true;
            this.bPush.Click += new System.EventHandler(this.bPush_Click);
            // 
            // tbInputLeft
            // 
            this.tbInputLeft.Location = new System.Drawing.Point(20, 153);
            this.tbInputLeft.Name = "tbInputLeft";
            this.tbInputLeft.Size = new System.Drawing.Size(100, 20);
            this.tbInputLeft.TabIndex = 1;
            this.tbInputLeft.Text = "0";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(126, 105);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(118, 134);
            this.listBox1.TabIndex = 7;
            // 
            // bPop
            // 
            this.bPop.Location = new System.Drawing.Point(250, 69);
            this.bPop.Name = "bPop";
            this.bPop.Size = new System.Drawing.Size(75, 23);
            this.bPop.TabIndex = 8;
            this.bPop.Text = "Pop";
            this.bPop.UseVisualStyleBackColor = true;
            this.bPop.Click += new System.EventHandler(this.bPop_Click);
            // 
            // tbRes
            // 
            this.tbRes.Location = new System.Drawing.Point(250, 153);
            this.tbRes.Name = "tbRes";
            this.tbRes.ReadOnly = true;
            this.tbRes.Size = new System.Drawing.Size(100, 20);
            this.tbRes.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 134);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Input";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(263, 134);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Output";
            // 
            // bTop
            // 
            this.bTop.Location = new System.Drawing.Point(250, 35);
            this.bTop.Name = "bTop";
            this.bTop.Size = new System.Drawing.Size(75, 23);
            this.bTop.TabIndex = 12;
            this.bTop.Text = "Top";
            this.bTop.UseVisualStyleBackColor = true;
            this.bTop.Click += new System.EventHandler(this.bTop_Click);
            // 
            // bEmpty
            // 
            this.bEmpty.Location = new System.Drawing.Point(149, 35);
            this.bEmpty.Name = "bEmpty";
            this.bEmpty.Size = new System.Drawing.Size(75, 23);
            this.bEmpty.TabIndex = 13;
            this.bEmpty.Text = "Is Empty";
            this.bEmpty.UseVisualStyleBackColor = true;
            this.bEmpty.Click += new System.EventHandler(this.bEmpty_Click);
            // 
            // bFull
            // 
            this.bFull.Location = new System.Drawing.Point(149, 69);
            this.bFull.Name = "bFull";
            this.bFull.Size = new System.Drawing.Size(75, 23);
            this.bFull.TabIndex = 14;
            this.bFull.Text = "Is Full";
            this.bFull.UseVisualStyleBackColor = true;
            this.bFull.Click += new System.EventHandler(this.bFull_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(389, 279);
            this.Controls.Add(this.bFull);
            this.Controls.Add(this.bEmpty);
            this.Controls.Add(this.bTop);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbRes);
            this.Controls.Add(this.bPop);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.tbInputLeft);
            this.Controls.Add(this.bPush);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bPush;
        private System.Windows.Forms.TextBox tbInputLeft;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button bPop;
        private System.Windows.Forms.TextBox tbRes;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button bTop;
        private System.Windows.Forms.Button bEmpty;
        private System.Windows.Forms.Button bFull;
    }
}

