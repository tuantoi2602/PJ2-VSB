﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Stack
{
    interface IMyStack
    {
        void Push(int i);
        int Pop();
        int Top();
        bool IsEmpty();
        bool IsFull();
    }
}
