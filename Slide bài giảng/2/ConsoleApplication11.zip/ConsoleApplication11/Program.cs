﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ConsoleApplication11
{
    class Program
    {
        static void Main(string[] args)
        {
            FileStream s = null;
            StreamWriter w = null;
            try
            {
                s = new FileStream(@"c:\tmp\output.txt", FileMode.Create);
                w = new StreamWriter(s);
                Writing(w);
            }
            finally
            {
                if (w != null) w.Dispose();
                if (s != null) s.Dispose();
            }

            //using (StreamWriter w = File.CreateText(@"c:\tmp\output.txt"))
            //{
            //    Writing(w);
            //}
                
            //Writing(Console.Out);
        }

        private static void Writing(TextWriter w)
        {
            w.WriteLine("Table of sqares:");
            for (int i = 0; i < 10; i++)
            {
                w.WriteLine("{0,3}: {1,5}", i, i * i);
            }
        }
    }
}
