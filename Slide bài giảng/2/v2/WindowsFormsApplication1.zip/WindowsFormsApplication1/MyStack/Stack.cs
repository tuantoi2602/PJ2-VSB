﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStack
{
   public class Stack: IStack
    {
        private int[] myarray;
        private int pointer=0;

        public  Stack()
        {
            myarray = new int[10];
        }
        public Stack(int x)
        {
            myarray = new int[x];
        }

        public int Top()
        {
            if (!IsEmpty())
                return myarray[pointer - 1];
            else
                Console.WriteLine("Array is empty");
            return -1;
        }

        public void Push(int x)
        {
            if(!IsFull())
            {
                myarray[pointer] = x;
                pointer++;
            }
            else
            {
                Console.WriteLine("Array is full");
            }
        }

        public int Pop()
        {
            if (!IsEmpty())
            {
                pointer--;
                return myarray[pointer];
            }
            else
            {
                Console.WriteLine("Array is empty");
            }
            return -1;
        }

        public int Size()
        {
            return myarray.Length;
        }
        public bool IsFull()
        {
            if (pointer == myarray.Length)
                return true;
            else
                return false;

        }
        
        public bool IsEmpty()
        {
            if (pointer == 0)
                return true;
            else
                return false;
        }
    }
}
