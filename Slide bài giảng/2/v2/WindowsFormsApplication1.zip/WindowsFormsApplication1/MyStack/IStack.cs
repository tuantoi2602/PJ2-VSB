﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStack
{
    interface IStack
    {
        int Top();
        void Push(int x);
        int Pop();

        int Size();

        bool IsFull();

        bool IsEmpty();
    }
}
