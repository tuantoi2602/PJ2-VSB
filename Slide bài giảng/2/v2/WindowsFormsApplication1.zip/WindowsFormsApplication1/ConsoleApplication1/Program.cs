﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyStack;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack tmp = new Stack();
            tmp.Push(1);
            tmp.Push(2);
            tmp.Push(30);
            tmp.Push(10);

            Console.WriteLine(tmp.Pop());
            Console.WriteLine(tmp.Pop());
            Console.WriteLine(tmp.Pop());
            Console.WriteLine(tmp.Pop());

        }
    }
}
