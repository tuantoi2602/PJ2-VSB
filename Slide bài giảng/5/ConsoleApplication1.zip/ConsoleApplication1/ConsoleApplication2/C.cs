﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class C
    {
        int sum = 0;

        #region version 1
        void SumUp(Node p)
        {
            sum += p.Value;
        }

        void Print(Node p)
        {
            Console.WriteLine(p.Value);
        }

        internal void Foo()
        {
            MyList list = new MyList(new int[] { 1, 5, 6, 4 });

            list.ForAll(SumUp);
            
            Console.WriteLine(sum);

            list.ForAll(Print);
        }
        #endregion

        #region version 2
        
        internal void Foo2()
        {
            MyList list = new MyList(new int[] { 1, 5, 6, 4 });

            list.ForAll(delegate(Node p) { sum += p.Value; });

            Console.WriteLine(sum);


            list.ForAll(delegate(Node p) { Console.WriteLine(p.Value); });
        }
        #endregion


        #region  version 3
        
        internal void Foo3()
        {
            MyList list = new MyList(new int[] { 1, 5, 6, 4 });

            Visitor visitor = delegate(Node p) { sum += p.Value; };
            visitor += delegate(Node p) { Console.WriteLine(p.Value); };

            list.ForAll(visitor);

            Console.WriteLine(sum);

            Visitor visitor2 = SumUp;
            visitor2 += Print;

            list.ForAll(visitor2);

            Console.WriteLine(sum);

        }
        #endregion
    }

}
