﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    delegate void Visitor(Node p);

    class MyList
    {
        Node[] data;

        public MyList(int[] values)
        {
            data = new Node[values.Length];
            for (int i = 0; i < values.Length; i++)
            {
                data[i] = new Node() { Value = values[i] };
            }
        }

        public void ForAll(Visitor visit)
        {
            for (int i = 0; i < data.Length; i++)
            {
                visit(data[i]);
            }
        }
    }

}
