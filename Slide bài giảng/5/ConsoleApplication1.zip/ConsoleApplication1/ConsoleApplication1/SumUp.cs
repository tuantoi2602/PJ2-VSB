﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class SumUp : IVisitor
    {
        public int Sum { get; set; }

        public void Visit(Node p)
        {
            Sum += p.Value;
        }
    }
}
