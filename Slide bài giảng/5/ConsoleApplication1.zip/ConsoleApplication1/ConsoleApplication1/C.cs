﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class C
    {
        int sum = 0;
        //void SumUp(Node p) { sum += p.value; }
        //void Print(Node p) { Console.WriteLine(p.value); }
      
        internal void Foo()
        {
            MyList list = new MyList(new int[] {1,5,6,4});

            SumUp sumUp = new SumUp() { Sum = sum };
            list.ForAll(sumUp);
            sum = sumUp.Sum;
            Console.WriteLine(sum);


            list.ForAll(new Print());
        }
    }

}
