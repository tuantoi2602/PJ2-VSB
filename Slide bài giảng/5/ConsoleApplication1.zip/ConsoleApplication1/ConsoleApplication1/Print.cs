﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Print : IVisitor
    {
        public void Visit(Node p)
        {
            Console.WriteLine(p.Value);
        }
    }
}
