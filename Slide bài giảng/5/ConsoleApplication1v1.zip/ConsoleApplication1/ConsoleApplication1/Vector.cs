﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public class Vector
    {
        private double x, y;

        public Vector(double x, double y) { this.x = x; this.y = y; }

        public double Length { get { return Math.Sqrt(x * x + y * y); } }

        public int CompareTo(Vector obj)
        {
                if (this.Length < obj.Length) return -1;
                else if (this.Length > obj.Length) return 1;
                else return 0;
        }
    }
    public class TestVector<T>: IComparer<T> where T:Vector
    {

        public int Compare(T a, T b)
        {
            if (a.Length < b.Length) return -1;
            else if (a.Length > b.Length) return 1;
            else return 0;
        }
    }
}
