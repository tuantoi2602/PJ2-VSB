﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Worker a = new Worker("Worker Tom", 5);
            Supervisor b = new Supervisor("Supervisor Mary", 6);
            Supervisor c = new Supervisor("Supervisor Jerry", 7);
            Supervisor d = new Supervisor("Supervisor Bob", 9);
            Worker e = new Worker("Worker Jimmy", 8);

       
            b.AddSubordinate(a); 
            c.AddSubordinate(b); 
            c.AddSubordinate(d); 
            d.AddSubordinate(e); 

 
            if (c is IEmployee)
                (c as IEmployee).ShowHappiness();
        }
    }




}
