﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPattern
{
    public class Invoice:Subject
    {
        public double amount;
        public DateTime dueDate;
        public DateTime date;

        public Invoice(double Amount, DateTime dueDate,DateTime date2)
        {
            this.amount = Amount;
            this.dueDate = dueDate;
            this.date = date2;
        }
        public void paid()
        {
            Notify();
        }

        public override string ToString()
        {
            return amount + ", " + dueDate.ToShortDateString() + " " + date.ToShortDateString();
        }
    }
}
