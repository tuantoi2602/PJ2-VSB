﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPattern
{
    public class PaymentMonitor : IObserver
    {
        public void Display(Invoice subject )
        {
            Console.WriteLine("Monitor:" + subject.ToString());
        }
        public void Update(Subject subject)
        {
            Invoice invoice = (Invoice)subject;
            Display(invoice);
        }
    }
}
