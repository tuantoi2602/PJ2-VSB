﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPattern
{
    public abstract class Subject
    {
        public List<IObserver> observers;
        public Subject()
        {
            observers = new List<IObserver>();
        }
        

        public void Attach(IObserver observer)
        {
            observers.Add(observer);
        }
        public void Dettach(IObserver observer)
        {
            observers.Remove(observer);
        }

        public void Notify()
        {
            foreach (IObserver item in observers)
            {
                item.Update(this);
            }
        }
    }
}
