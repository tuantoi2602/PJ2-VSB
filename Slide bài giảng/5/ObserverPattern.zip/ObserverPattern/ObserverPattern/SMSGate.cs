﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPattern
{
    public class SMSGate : IObserver
    {
        public string phone;

        public void Send(string text)
        {
            Console.WriteLine("SMSGate:" + text);
        }
        public void Update(Subject subject)
        {
            Send(((Invoice)subject).ToString());
        }
    }
}
