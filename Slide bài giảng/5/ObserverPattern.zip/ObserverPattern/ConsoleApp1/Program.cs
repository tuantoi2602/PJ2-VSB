﻿using ObserverPattern;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Invoice invoice = new Invoice(20,DateTime.Now,DateTime.Now.AddYears(20));
            SMSGate sMSGate = new SMSGate();
            SMSGate sMSGate2 = new SMSGate();
            SMSGate sMSGate3 = new SMSGate();
            PaymentMonitor paymentMonitor = new PaymentMonitor();


            invoice.Attach(sMSGate);
            invoice.Attach(sMSGate2);
            invoice.Attach(sMSGate3);
            invoice.Attach(paymentMonitor);

            invoice.paid();
        }
    }
}
