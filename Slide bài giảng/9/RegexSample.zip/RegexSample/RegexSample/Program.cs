﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
//using d = System.Text.RegularExpressions;


namespace RegexSample
{
    class Program
    {
        static void Main(string[] args)
        {
            //Example1();
            //xample2();
            //Example3();
            //Example4();
            //Example5();
            //Example6();
            //Example7();
            //Example8();
            Example9();
        }

        private static void Example9()
        {
            string str = Regex.Replace("Hello World", "Hello", "Goodbye");
            System.Console.WriteLine(str);

            string a = "abcd hello ello yellow";
            str = Regex.Replace(a, @"\b\w{4}\b", "****");
            System.Console.WriteLine(str);

            str = "30\"50 100\"200 123\"647 952\"142 5\"1231";
            string search = @"(\d+)""(\d+)";
            string replace = "$0:$2-$1";
            str = Regex.Replace(str, search, replace);
            System.Console.WriteLine(str);
        }

        private static void Example8()
        {
            string str = "$1.57 $316.15 $19.30 $0.30 $0.00 $41.10 $5.1 $.5";
            string strMatch = @"\$(\d*)\.(\d\d)";

            for (Match m = Regex.Match(str, strMatch); m.Success; m = m.NextMatch())
            {
                System.Console.Write("{0},{1} Kc ", int.Parse(m.Groups[1].Value) , m.Groups[2].Value);
            }
        }

        private static void Example7()
        {
            string str = "$1.57 $316.15 $19.30 $0.30 $0.00 $41.10 $5.1 $.5";
            string strMatch = @"\$(\d)\.(\d\d)";

            for (Match m = Regex.Match(str, strMatch); m.Success; m = m.NextMatch())
            {
                GroupCollection gc = m.Groups;

                System.Console.WriteLine("The number of captures: " + gc.Count);
                // Group 0 is the entire matched string itself
                // while Group 1 is the first group to be captured.
                for (int i = 0; i < gc.Count; i++)
                {
                    Group g = gc[i];
                    System.Console.WriteLine(g.Value);
                }
            }
        }

        private static void Example6()
        {
            string str = "$1.57 $316.15 $19.30 $0.30 $0.00 $41.10 $5.1 $.5";
            string strMatch = @"\$\d+\.\d\d";

            for (Match m = Regex.Match(str, strMatch); m.Success; m = m.NextMatch())
            {
                System.Console.WriteLine(m);
            }
        }

        private static void Example5()
        {
            string str = "HelloBelloYelloHallo";
            string strMatch = @"\wello";

            {

                Match m = Regex.Match(str, strMatch);
                while (m.Success)
                {
                    System.Console.WriteLine(m);
                    m = m.NextMatch();
                }

            }
        }

        private static void Example4()
        {
            string[] id = { "123-45-6789", 
                "1234-5-6789 ", 
                "547-12-6346 547-12-6346", 
                "54-12-5623",
                "3513-15134",
                "608-12-61347",
                "8608-12-6134",
                "608-12-6134" };

            for (int i = 0; i < id.Length; i++)
            {
                for (Match m = Regex.Match(id[i], @"\d{3}-\d{2}-\d{4}"); m.Success; m = m.NextMatch())
                {
                    Console.WriteLine(m);
                }
            }
        }

        private static void Example3()
        {
            string data = "Hello World!";
            Match m = Regex.Match(data, "Hello");
            System.Console.WriteLine("{0} {1} {2}", m.ToString(), m.Success, m.Value);
        }

        private static void Example2()
        {
            string[] id = 
                { 
                    "123-45-6789", 
                    "1234-5-6789", 
                    "5473-12-6346 547-12-6346", 
                    "54-12-5623",
                    "3513-15134",
                    "608-12-61347",
                    "8608-12-6134",
                    "608-12-6134" 
                };

            for (int i = 0; i < id.Length; i++)
            {
                //if (Regex.IsMatch(id[i], @"\d{3}-\d{2}-\d{4}"))
                if (Regex.IsMatch(id[i], @"\b\d{3}-\d{2}-\d{4}\b"))
                {
                    System.Console.WriteLine(id[i]);
                }
            }
        }

        private static void Example1()
        {
            string data = "Hello World!";
            if (Regex.IsMatch(data, "Hello"))
            {
                System.Console.WriteLine("1: Hello Found, joy!");
            }
            data = "Goodbye World!";
            if (Regex.IsMatch(data, "Hello"))
            {
                System.Console.WriteLine("2: Hello Found, joy!");
            }
        }
    }
}
