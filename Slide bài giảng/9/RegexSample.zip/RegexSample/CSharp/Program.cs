﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CSharp
{
    class Program
    {
        delegate TResult Func<in T, out TResult>(T arg);

        static void Main(string[] args)
        {
            //IEnumerable<object> objects;
            //objects = GetStrings();

            Func<string, object> fce;
            fce = Fce;
        }

        private static string Fce(object s)
        {
            return s.ToString();
        }

        private static IEnumerable<string> GetStrings()
        {
            return new string[] { "a", "b", "c" };
        }

    }
}
