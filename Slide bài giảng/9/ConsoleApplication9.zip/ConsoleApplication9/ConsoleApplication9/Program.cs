﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace ConsoleApplication9
{

    class TestThreads
    {
        private Object ForLock = new Object();
        List<int> numbers;
        string nameOfFile = "test.txt";
        public int sum = 0;
        int IDthreads = 0;

        public void LoadFile()
        {
            numbers = new List<int>();
            string line;
            using (System.IO.StreamReader file = new System.IO.StreamReader(nameOfFile))
            {
                int tempsum = 0;
                while ((line = file.ReadLine()) != null)
                {
                    tempsum += Convert.ToInt32(line);
                    numbers.Add(Convert.ToInt32(line));

                }
                Console.WriteLine("Total sum is:" + tempsum);
            }

        }
        public void Sum()
        {
            int localID = 0;
            lock (ForLock)
            {
                localID = IDthreads;
                IDthreads++;
                Console.WriteLine("Thread:" + localID);
            }
            int tempSum = 0;
            for (int i = localID; i < numbers.Count; i = i + 2)
            {
                tempSum += numbers[i];
            }
            lock (ForLock)
            {
                sum += tempSum;
            }
        }
    }

    class Program
    {
        static void generateFile(string nameOfFile)
        {
            Random rand = new Random();
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(nameOfFile))
            {

                for (int i = 0; i < 300; i++)
                {
                    file.WriteLine(Convert.ToInt32(rand.NextDouble() * 1000)); 
                }

            }

        }
        static void Main(string[] args)
        {
            generateFile("test.txt");
            TestThreads test = new TestThreads();
            Thread tmpTh = new Thread(new ThreadStart(test.LoadFile));
            tmpTh.Start();
            tmpTh.Join();
            

            Thread tmpTh1 = new Thread(new ThreadStart(test.Sum));
            Thread tmpTh2 = new Thread(new ThreadStart(test.Sum));
            tmpTh1.Start();
            tmpTh2.Start();

            tmpTh1.Join();
            tmpTh2.Join();
            Console.WriteLine("Total sum is:" + test.sum);


        }
 
    }
}
