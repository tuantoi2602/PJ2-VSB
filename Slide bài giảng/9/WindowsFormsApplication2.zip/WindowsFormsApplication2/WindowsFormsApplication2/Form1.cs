﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        private System.Timers.Timer mytime;
        private int myCounter;

        public Form1()
        {
            InitializeComponent();
            mytime = new System.Timers.Timer();
            myCounter = 0;
            mytime.Elapsed += mytime_Elapsed;
        }

        void mytime_Elapsed(object sender, ElapsedEventArgs e)
        {
            myCounter++;
            tbCounter.Text = myCounter.ToString();
        }

 

        private void bStart_Click(object sender, EventArgs e)
        {
            try
            {
             int temp= Convert.ToInt32(tbDelay.Text)*100+1;
            if(temp<=0)
                temp=1;
            mytime.Interval = temp;
            }
            catch (Exception ex)
            {

            }
            mytime.Start();
        }

        private void bStop_Click(object sender, EventArgs e)
        {
            mytime.Stop();
        }

        private void bReset_Click(object sender, EventArgs e)
        {
            myCounter = 0;
            tbCounter.Text = myCounter.ToString();
        }



        private void tbDelay_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int temp = Convert.ToInt32(int.Parse(tbDelay.Text)) * 100 + 1;
                if (temp <= 0)
                    temp = 1;
                mytime.Interval = temp;
            }catch(Exception ex)
            {

            }
        }


    }
}
