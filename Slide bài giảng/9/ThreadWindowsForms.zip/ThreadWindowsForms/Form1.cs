﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace ThreadWindowsForms
{
    public partial class Form1 : Form
    {
        int counter = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Thread t = new Thread(Run);
            //t.Start();
            //backgroundWorker1.RunWorkerAsync();
            timer1.Enabled = true;
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
                    label1.Text = counter.ToString();
                    counter++;
                    Thread.Sleep(100);
               
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = counter.ToString();
            counter++;
        }

        //private void Run()
        //{
        //    while (true)
        //    {
        //        label1.Text = counter.ToString();
        //        counter++;
        //    }
        //}
    }
}
