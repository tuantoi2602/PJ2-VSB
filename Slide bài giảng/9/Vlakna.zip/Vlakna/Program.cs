﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Vlakna
{
    class Test
    {
        char znak;

        public Test(char znak)
        {
            this.znak = znak;
        }

        public void Run()
        {
            lock (Console.Out)
            {
                Console.WriteLine("Name: {0}", Thread.CurrentThread.ManagedThreadId);
                for (int i = 0; i < 10; i++)
                {
                    Console.Write(znak);
                    Thread.Sleep(100);
                }
                Console.WriteLine();
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Name: {0}", Thread.CurrentThread.ManagedThreadId);
            
            Test test1 = new Test('*');
            Test test2 = new Test('+');
            
            Thread run1 = new Thread(test1.Run);
            Thread run2 = new Thread(test2.Run);

            run1.Start();
            run2.Start();
            Thread.Sleep(200);
            run1.Abort();

        }

    }
}
