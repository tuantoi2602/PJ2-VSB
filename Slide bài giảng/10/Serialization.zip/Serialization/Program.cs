﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Serialization
{
    class Program
    {
        int a;

        void Test()
        {
            Console.WriteLine("Test Main:" + a);
        }

        static void Main(string[] args)
        {
            ContactCard c1 = new ContactCard("Pepa", 20);
            
            using (FileStream txtFile = new FileStream(@"d:\test.txt", FileMode.Create))
            using (StreamWriter wr = new StreamWriter(txtFile))
            {
                wr.WriteLine(c1.Name);
                wr.WriteLine(c1.Age);
            }

            using (FileStream binFile = new FileStream(@"d:\test.bin", FileMode.Create))
            using (BinaryWriter wrB = new BinaryWriter(binFile))
            {
                wrB.Write(c1.Name);
                wrB.Write(c1.Age);
            }

            ContactCard[] cArray = new ContactCard[2];
            
            Address a = new Address("Street", "Kocourkov", "55 555");
            cArray[0] = c1;
            cArray[0].Address = a;
            cArray[1] = new ContactCard("John", 23);
            cArray[1].Address = a;

            cArray[0].UpdateDelegates += delegate
            {
                Console.WriteLine("hahah Update!!!!!!");
            };
            cArray[1].UpdateDelegates += delegate
            {
                Console.WriteLine("hahah Update Second!!!!!!");
            };

            Program p = new Program();
            p.a = 33;
            cArray[0].UpdateDelegates += p.Test;


            //foreach (ContactCard c in cArray)
            //{
            //    Console.WriteLine(c.ToString());
            //}

            foreach (ContactCard c in cArray)
            {
                c.CallUpdateToAllDelegates();
            }

            using (FileStream xmlFile = new FileStream(@"d:\test.xml", FileMode.Create))
            {
                XmlSerializer xmlSer = new XmlSerializer(typeof(ContactCard[]));
                xmlSer.Serialize(xmlFile, cArray);
            }

            using (FileStream binSFile = new FileStream(@"d:\test2.bin", FileMode.Create))
            {
                BinaryFormatter binSer = new BinaryFormatter();
                binSer.Serialize(binSFile, cArray);
            }
            
            c1 = new ContactCard();
            Console.WriteLine("------txt reader--------");

            using (FileStream txtFile2 = new FileStream(@"d:\test.txt", FileMode.Open))
            {
                StreamReader rd = new StreamReader(txtFile2);
                c1.Name = rd.ReadLine();
                c1.Age = int.Parse(rd.ReadLine());
            }
            Console.WriteLine(c1.ToString());

            Console.WriteLine("------bin reader--------");
            using (FileStream binFile2 = new FileStream(@"d:\test.bin", FileMode.Open))
            {
                BinaryReader rdB = new BinaryReader(binFile2);
                c1.Name = rdB.ReadString();
                c1.Age = rdB.ReadInt32();
            }
            Console.WriteLine(c1.ToString());

            using (FileStream xmlFile = new FileStream(@"d:\test.xml", FileMode.Open))
            {
                XmlSerializer xmlSer = new XmlSerializer(typeof(ContactCard[]));
                ContactCard[] array = (ContactCard[])xmlSer.Deserialize(xmlFile);
                
                Console.WriteLine("------XML ser--------");
                foreach (ContactCard c in array)
                {
                    //Console.WriteLine(c.ToString());
                    c.CallUpdateToAllDelegates();
                }
            }

            using (FileStream binSFile = new FileStream(@"d:\test2.bin", FileMode.Open))
            {
                BinaryFormatter binSer = new BinaryFormatter();
                ContactCard[] array = (ContactCard[])binSer.Deserialize(binSFile);
        
                Console.WriteLine("------BIN Ser--------");
                foreach (ContactCard c in array)
                {
                    //Console.WriteLine(c.ToString());
                    c.CallUpdateToAllDelegates();
                }
            }
            Console.ReadKey();
        }
    }

    [Serializable]
    public class ContactCard
    {
        public delegate void Update();

        [field: NonSerialized]
        public event Update UpdateDelegates;

        [NonSerialized]
        protected string name = "";
        public string Name { get { return name; } set { name = value; } }

        protected int age = 0;
        [XmlIgnore]
        public int Age { get { return age; } set { age = value; } }

        protected double weight = 0;
        public double Weight { get { return weight; } set { weight = value; } }

        protected string email = "";
        public string Email { get { return email; } set { email = value; } }

        protected DateTime dayOfBirth;
        public DateTime DayOfBirth { get { return dayOfBirth; } set { dayOfBirth = value; } }

        protected bool maried;
        public bool Maried { get { return maried; } set { maried = value; } }

        protected Address address = new Address();
        public Address Address { get { return address; } set { this.address = value; } }

        public ContactCard()
            : this("none", 0)
        {
        }

        public ContactCard(string name, int age)
            : this(name, age, 50.5, "noname@nonet.net", new DateTime(), false, new Address())
        {
        }

        public ContactCard(string name, int age, double weight, string email, DateTime dayOfBirth, bool maried, Address address)
        {
            this.Name = name;
            this.Age = age;
            this.Weight = weight;
            this.Email = email;
            this.DayOfBirth = dayOfBirth;
            this.Maried = maried;
            this.Address = address;
        }
        public override  string ToString()
        {
            return "[ContactCard: " + this.GetHashCode() + ",\r\n  " + Name + ", " + Age + ", " + Weight + ",\r\n  " + Email + ", " + DayOfBirth + ", " + Maried + ",\r\n" + Address.ToString() + "\r\n]";
        }

        public void CallUpdateToAllDelegates()
        {
            if (UpdateDelegates != null)
            {
                UpdateDelegates();
            }

        }
    }

    [Serializable]
    public class Address
    {
        protected string street = "";
        public string Street { get { return street; } set { street = value; } }

        protected string city = "";
        public string City { get { return city; } set { city = value; } }

        protected string zipCode = "";
        public string ZipCode { get { return zipCode; } set { zipCode = value; } }


        public Address()
            : this("street", "Ostrava", "007")
        {
        }

        public Address(String street, string city, string zipCode)
        {
            this.Street = street;
            this.City = city;
            this.ZipCode = zipCode;
        }

        public override string ToString()
        {
            return "  [Address: " + this.GetHashCode() + ",\r\n    " + Street + ", " + City + ", " + ZipCode + "\r\n  ]";
        }
    }
}
