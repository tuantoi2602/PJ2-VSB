﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    enum EFilmTyp { comedy, drama}

    public class MyEventArgs : EventArgs
    {
        private string EventInfo;
        public MyEventArgs(string Text)
        {
            EventInfo = Text;
        }
        public string GetInfo()
        {
            return EventInfo;
        }
    }

    class Film : IItem
    {
        public delegate void MyEventHandler(object source, MyEventArgs e);
        public event MyEventHandler ChangeNotify;


        public string Name { get ; set ; }
        public int ID { get ; set; }
        public EFilmTyp Genre { get; set; }

        public Film(string name, int id)
        {
            Name = name;
            ID = id;
        }

        private DateTime timeTo,timeFrom;

        public DateTime borrowingTo
        {
            set
            {
                timeTo = value;
                MyEventHandler handler = ChangeNotify;
                if (handler != null)
                {
                    handler(this, new MyEventArgs("You've entered: "+ value.ToString()));
                }
            }

            get
            {
                return timeTo;
            }

        }

        public DateTime borrowinFrom
        {
            set
            {
                timeFrom = value;
            }

            get
            {
                return timeFrom;
            }

        }
    }
}
