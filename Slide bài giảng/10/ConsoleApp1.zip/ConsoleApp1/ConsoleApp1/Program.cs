﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Filmdistributor fd = new Filmdistributor();
            Film a = new Film("bbb",1);
            Film b = new Film("aaaa", 2);
            Film c = new Film("ccc", 3);

            fd.AddItem(a); fd.AddItem(b); fd.AddItem(c);

            fd.Change();


        }
    }
}
