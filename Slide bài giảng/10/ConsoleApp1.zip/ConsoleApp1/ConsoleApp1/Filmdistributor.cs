﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Filmdistributor
    {
        List<IItem> poolOfitems = new List<IItem>();

        public void AddItem (IItem item)
        {
           if(item is Film)
            {
                ((Film)item).ChangeNotify += c_ThresholdReached;
            }
            poolOfitems.Add(item);
        }


       public void Change()
        {
            ((Film)poolOfitems[0]).borrowingTo=DateTime.Now;
        }

        static void c_ThresholdReached(object sender, MyEventArgs e)
        {
            Console.WriteLine(e.GetInfo());
          
        }

        public 

    }
}
