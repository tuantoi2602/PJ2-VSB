﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Audio : IItem
    {
        public string Name { get; set ; }
        public int ID { get ; set; }

        public int Lenght { get; set; }
        public string Arthur { get; set; }
    }
}
