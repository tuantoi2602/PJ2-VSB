﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using System.Xml.XPath;

namespace XMLReaderWrite
{
    class Program
    {
        static string path = @"d:\Courses\leto 2012\PJ II\prednasky\8\XMLReaderWrite\Data.xml";
        static string pathSchema = @"d:\Courses\leto 2012\PJ II\prednasky\8\XMLReaderWrite\Data1.xsd";
        static string pathWriting = @"d:\Courses\leto 2012\PJ II\prednasky\8\XMLReaderWrite\ClassesOut.xml";
        static string pathAddressBook = @"d:\Courses\leto 2012\PJ II\prednasky\8\XMLReaderWrite\AddressBook.xml";
        static string pathDom = @"d:\Courses\leto 2012\PJ II\prednasky\8\XMLReaderWrite\domNew.xml";

        static void Main(string[] args)
        {
            //ReadAddressBook(pathAddressBook);
            //ClassInfo(new XmlTextReader(path));
            //Validation(path, pathSchema);
            //WriteClass(pathWriting);
            //Dom1(path);
            //CreateDom(pathDom);
            //XPath1(path);
            //XPath2(path);
            //XPath3(pathAddressBook);
        }

        private static void XPath3(string pathAddressBook)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(pathAddressBook);
            XPathNavigator nav = doc.CreateNavigator();

            XPathNodeIterator iterator = nav.Select("/addressbook/*/firstname");
            while (iterator.MoveNext())
                Console.WriteLine(iterator.Current.Value);

            XPathExpression expr = nav.Compile("/addressbook/person[firstname='Wolfgang']/email");
            iterator = nav.Select(expr);
            while (iterator.MoveNext()) Console.WriteLine(iterator.Current.Value);

        }

        private static void XPath2(string path)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(path);

            XmlNamespaceManager nsmgr = new XmlNamespaceManager(doc.NameTable);
            nsmgr.AddNamespace("ab", "http://example.books.com");
        }

        static void ShowAuthorFirstNames(XmlNode node, XmlNamespaceManager nsmgr)
        {
            XmlNodeList nl = node.SelectNodes("//ab:first-name", nsmgr);
            foreach (XmlNode n in nl)
            {
                Console.WriteLine("Student:{0}", n.InnerText);
            }
        }

        private static void XPath1(string path)
        {
            XPathDocument doc = new XPathDocument(path);
            XPathNavigator nav = doc.CreateNavigator();
            TreeWalkX(nav);
        }

        static void TreeWalkX(XPathNavigator nav)
        {
            
            Console.WriteLine("Type: {0}\tName: {1}\tValue: {2}",
                     nav.NodeType, nav.Name, nav.Value);
            if (nav.HasChildren)
            {
                nav.MoveToFirstChild();
                TreeWalkX(nav);
                nav.MoveToParent();
            }
            if (nav.MoveToNext())
                TreeWalkX(nav);
        }

        private static void CreateDom(string pathDom)
        {
            XmlDocument doc = new XmlDocument();

            //doc.NodeInserted += new XmlNodeChangedEventHandler(doc_NodeInserted);
       
            XmlDeclaration decl = doc.CreateXmlDeclaration("1.0", null, null);
            doc.AppendChild(decl);

            XmlElement rootElem = doc.CreateElement("addressbook");
            rootElem.SetAttribute("owner", "1");
            doc.AppendChild(rootElem);

            XmlElement person = doc.CreateElement("person");
            person.SetAttribute("id", "1");
            XmlElement f = doc.CreateElement("firstname");
            f.AppendChild(doc.CreateTextNode("Wolfgang"));
            person.AppendChild(f);
            XmlElement l = doc.CreateElement("lastname");

            rootElem.AppendChild(person);
            person.AppendChild(f);
            person.AppendChild(l);

            doc.Save(pathDom);
        }

        static void doc_NodeInserted(object sender, XmlNodeChangedEventArgs e)
        {
            Console.WriteLine("New Node: {0}", e.Node.Name);
        }

        private static void Dom1(string path)
        {
            XmlDocument dom = new XmlDocument();
            dom.Load(path);

            //TreeWalk(dom);

            //CollectWalk(dom);

            CollectWalk2(dom);
        }


        static void TreeWalk(XmlNode node)
        {
            if (node == null)
                return;
            Console.WriteLine("Type: {0}\tName: {1}\tValue: {2}",
                     node.NodeType, node.Name, node.Value);
            TreeWalk(node.FirstChild);
            TreeWalk(node.NextSibling);
        }

        static void CollectWalk(XmlNode node)
        {
            Console.WriteLine("Type: {0}\tName: {1}\tValue: {2}",
                        node.NodeType, node.Name, node.Value);

            if (node.HasChildNodes)
            {
                XmlNodeList nodeList = node.ChildNodes;
                foreach (XmlNode child in nodeList)
                    CollectWalk(child);
            }
        }

        static void CollectWalk2(XmlNode node)
        {
            Console.WriteLine("Type: {0}\tName: {1}\tValue: {2}",
                        node.NodeType, node.Name, node.Value);

            if (node.Attributes != null)
                foreach (XmlAttribute Attr in node.Attributes)
                    Console.WriteLine("\tAttr: {0}={1}",
                          Attr.Name, Attr.Value);

            if (node.HasChildNodes)
            {
                XmlNodeList nodeList = node.ChildNodes;
                foreach (XmlNode child in nodeList)
                    CollectWalk2(child);
            }
        }

        static void ReadAddressBook(string path)
        {
            using (XmlTextReader r = new XmlTextReader(path))
            {
                while (r.Read())
                {
                    if (r.IsStartElement("lastname"))
                    {
                        r.Read();	//  read the name
                        Console.Write("{0}, ", r.Value);
                    }
                }
            }
        }

        static void WriteClass(string pathWriting)
        {
            using (XmlTextWriter wrt = new XmlTextWriter(pathWriting, Encoding.UTF8))
            {
                wrt.Formatting = Formatting.Indented;
                wrt.WriteStartDocument();
                wrt.WriteStartElement("Classes");
                wrt.WriteAttributeString("name", ".NET XML");
                wrt.WriteElementString("Students", "12");
                wrt.WriteElementString("Location", "Maine Bytes");
                wrt.WriteElementString("Instructor", "Jim");
            }
        }

        private static void Validation(string path, string pathSchema)
        {
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.Schemas.Add(null, XmlReader.Create(pathSchema));
            settings.ValidationType = ValidationType.Schema;
            settings.ValidationEventHandler += Settings_ValidationEventHandler;
            // Create the XmlReader object.
            XmlReader TRdr = XmlReader.Create(path, settings);
            // Parse the file. 
            while (TRdr.Read()) ;
        }

        static void Settings_ValidationEventHandler(object sender, ValidationEventArgs e)
        {
            Console.WriteLine(e.Message);
        }



        static void ClassInfo(XmlTextReader Rdr)
        {
            Rdr.MoveToContent();
            Rdr.ReadStartElement("bookstore");
            Rdr.MoveToContent();
            while (Rdr.Name == "book")
            {
                Console.WriteLine("{0}|", Rdr["ISBN"]);
                Rdr.ReadStartElement("book");
                Console.WriteLine(Rdr.ReadElementString("title"));
                Rdr.ReadStartElement("author");
                Console.WriteLine("{0}|", Rdr.ReadElementString("first-name"));
                Console.WriteLine("{0}|", Rdr.ReadElementString("last-name"));
                Rdr.ReadEndElement();
                Console.WriteLine("{0}", Rdr.ReadElementString("price"));
                Rdr.ReadEndElement();
                Rdr.MoveToContent();
            }
        }
    }
}
