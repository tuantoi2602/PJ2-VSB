﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Net;
using System.Xml.XPath;

namespace pj2_2013_cv9
{
    class Program
    {
        static void Main(string[] args)
        {
            using (WebClient wc = new WebClient())
            {
                //wc.DownloadFile("http://feeds.bbci.co.uk/news/health/rss.xml", "...");

                string s = wc.DownloadString("http://feeds.bbci.co.uk/news/health/rss.xml");
                XmlDocument xml = new XmlDocument();
                xml.LoadXml(s);
                xml.NodeRemoved += NodeRemoved;
                Console.WriteLine("Filtred items in the channel (xpath):");
                XPathNavigator nav = xml.CreateNavigator();
                XPathNodeIterator it = nav.Select("/rss/channel/item/title[contains(text(), \"VIDEO\")]");
                while (it.MoveNext())
                {
                    Console.WriteLine(it.Current.Value);
                }
                Console.WriteLine();
                Console.WriteLine("Filtred items in the channel (child nodex):");
                foreach (XmlNode node in xml["rss"]["channel"].ChildNodes)
                {
                    if (node.Name.Equals("item") && node["title"].InnerText.StartsWith("VIDEO"))
                    {
                        Console.WriteLine(node["title"].InnerText);
                    }
                }

                List<XmlNode> toRemove = new List<XmlNode>();
                foreach (XmlNode node in xml["rss"]["channel"].ChildNodes)
                {
                    if (!(node.Name.Equals("item") && node["title"].InnerText.StartsWith("VIDEO")))
                    {
                        toRemove.Add(node);
                    }
                }
                foreach (XmlNode node in toRemove)
                {
                    xml["rss"]["channel"].RemoveChild(node);
                }
                Console.WriteLine();
                Console.WriteLine("All items in the channel:");
                foreach (XmlNode node in xml["rss"]["channel"].ChildNodes)
                {
                    if (node.Name.Equals("item"))
                    {
                        Console.WriteLine(node["title"].InnerText);
                    }
                }

                xml.Save(@"d:\bbc.xml");

                Console.WriteLine();
                Console.WriteLine("Reading by using XmlTextReader");
                XmlTextReader tr = new XmlTextReader("http://feeds.bbci.co.uk/news/health/rss.xml");
                while (tr.Read())
                {
                    if (tr.IsStartElement("title"))
                    {
                        tr.Read();
                        if (tr.Value.StartsWith("VIDEO"))
                        {
                            Console.WriteLine(tr.Value);
                        }
                    }
                }

                xml.LoadXml(s);
                toRemove.Clear();
                search(xml, toRemove);
                foreach (XmlNode n in toRemove)
                {
                    n.ParentNode.RemoveChild(n);
                }
                xml.Save(@"d:\bbc2.xml");
                
                xml.LoadXml(s);
                using(XmlTextWriter w = new XmlTextWriter(@"D:\bbc3.xml", Encoding.UTF8))
                {
                    w.Formatting = Formatting.Indented;
                    w.WriteStartDocument();
                    w.WriteStartElement("rss");
                    foreach (XmlNode node in xml["rss"]["channel"].ChildNodes)
                    {
                        if (node.Name.Equals("item") && node["title"].InnerText.StartsWith("VIDEO"))
                        {
                            //w.WriteStartElement("item");
                            //w.WriteStartElement("title");
                            //w.WriteString(node["title"].InnerText);
                            //w.WriteEndElement();
                            //w.WriteStartElement("description");
                            //w.WriteString(node["description"].InnerText);
                            //w.WriteEndElement();
                            //w.WriteStartElement("link");
                            //w.WriteString(node["link"].InnerText);
                            //w.WriteEndElement();
                            //w.WriteStartElement("guit");
                            //w.WriteAttributeString("isPermaLink", node["guid"].Attributes["isPermaLink"].Value);
                            //w.WriteString(node["guid"].InnerText);
                            //w.WriteEndElement();
                            //w.WriteEndElement();
                            writeElement(w, node);
                        }
                    }
                    w.WriteEndElement();
                    w.WriteEndDocument();
                }


                Console.ReadKey();
            }
        }

        public static void writeElement(XmlTextWriter w, XmlNode srcNode)
        {
            w.WriteStartElement(srcNode.Name);
            foreach (XmlAttribute a in srcNode.Attributes)
            {
                w.WriteAttributeString(a.Name, a.Value);
            }
            foreach (XmlNode n in srcNode.ChildNodes)
            {
                if (n.NodeType == XmlNodeType.Element)
                {
                    writeElement(w, n);
                }
                else if (n.NodeType == XmlNodeType.Text)
                {
                    w.WriteString(n.InnerText);
                }
            }
            w.WriteEndElement();
        }

        public static void search(XmlNode node, IList<XmlNode> toRemove)
        {
            foreach (XmlNode n in node.ChildNodes)
            {
                if (!n.InnerText.Contains("VIDEO"))
                {
                    toRemove.Add(n);
                }
                else
                {
                    search(n, toRemove);
                }
            }
        }

        public static void NodeRemoved(object sender, XmlNodeChangedEventArgs e)
        {
            Console.WriteLine("Sender{0} remove node {1}", sender, e.Node.Name);
        }
    }
}
