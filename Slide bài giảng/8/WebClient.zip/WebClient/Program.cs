﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Net;


namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            using (WebClient wc = new WebClient())
            {
                string s = wc.DownloadString(@"http:\\www.vsb.cz");
                Console.Write(s);
            }
        }
    }
}
