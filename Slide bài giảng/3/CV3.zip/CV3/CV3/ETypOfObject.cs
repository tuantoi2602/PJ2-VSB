﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CV3
{
    enum ETypOfObject
    {
        Circle = 1,
        Rectangle = 2
    }
}
