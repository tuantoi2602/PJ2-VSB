﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CV3
{
    class Circle: GraphObject
    {

        public Circle(int r, int x, int y) : base(2*r, 2*r, x, y)
        {
        }

        public override void Print()
        {
            Console.WriteLine("Circle[radius={0,5:E}, X={1,5:P}, Y={2,5:X}]", Radius, X, Y);
        }

        public int Radius 
        {
            get { return width / 2; }
            set { height = value * 2; height = value * 2; }
        }
    }
    
}
