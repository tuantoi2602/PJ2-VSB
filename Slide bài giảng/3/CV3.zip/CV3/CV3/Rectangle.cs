﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CV3
{
    class Rectangle:GraphObject
    {
        public override void Print()
        {
            Console.WriteLine("Rectangle[width={0,5:E}, height={1,5:C}, X={2,5:P}, Y={3,5:X}]", width, height, X, Y);
        }
        public Rectangle(int v, int s, int x, int y)
            : base(v, s, x, y)
        {
        }
    }
}
