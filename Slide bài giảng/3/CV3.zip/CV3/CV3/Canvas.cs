﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CV3
{
    class Canvas
    {
         private GraphObject[] objects;

         public Canvas(int size)
        {
            objects = new GraphObject[size];
        }

         int Number { get { return objects.Length; } }

        public GraphObject this[int index]{
            get { return objects[index]; }
            set { objects[index] = value; }
        }

        public void Print()
        {
            foreach (GraphObject g in objects)
            {
                if (g != null)
                {
                    g.Print();
                }
                else
                {
                    Console.WriteLine("null");
                }
            }
        }
        public void TurnRectangles()
        {
            foreach (GraphObject g in objects)
            {
                if (g is Rectangle)
                {
                    g.Turn();
                }
            }
        }
    }
}
