﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CV3
{
    abstract class GraphObject
    {
        protected int width;
        protected int height;

        public int X { get; set; }
        public int Y { get; set; }

        public GraphObject(int height, int width, int x, int y)
        {
            this.width = width;
            this.height = height;
            this.X = x;
            this.Y = y;
        }

        public abstract void Print();
        public void Turn()
        {
            Turn(ref width, ref height);
        }
        private void Turn(ref int s, ref int v)
        {
            int tmp = v;
            v = s;
            s = tmp;
        }
    }
}
