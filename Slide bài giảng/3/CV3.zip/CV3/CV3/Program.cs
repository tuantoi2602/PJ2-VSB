﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CV3
{
    class Program
    {
        static void Main(string[] args)
        {
            Canvas canvas = new Canvas(args.Length);
            for (int i = 0; i < args.Length; i++)
            {
                int type;
                if (int.TryParse(args[i], out type))
                {
                    ETypOfObject typOfObject = (ETypOfObject)type;
                    switch (typOfObject)
                    {
                        case ETypOfObject.Circle:
                            canvas[i] = new Circle(i, i * 1000, i * 2000);
                            break;
                        case ETypOfObject.Rectangle:
                            canvas[i] = new Rectangle(i * 100, i * 200, i * 1000, i * 2000);
                            break;
                    }
                }
            }
            canvas.Print();
            canvas.TurnRectangles();
            Console.WriteLine("After function Turn.");
            canvas.Print();
            Console.ReadKey();
        }
    }
}
