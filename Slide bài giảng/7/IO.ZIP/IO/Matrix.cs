using System;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.IO.IsolatedStorage;

namespace ca5
{
    class Matrix
    {
        private readonly int rows;
        private readonly int columns;
        private readonly float[][] data;

        public float[][] Data
        {
            get { return data; }
        }

        public int Rows
        {
            get { return rows; }
        }

        public int Columns
        {
            get { return columns; }
        }

        public Matrix(int rows, int columns)
        {
            this.rows = rows;
            this.columns = columns;
            data = new float[rows][];
            for (int i = 0; i < rows; i++)
            {
                data[i] = new float[columns];
            }
        }

        public void RandomInit(int maxValue)
        {
            Random random = new Random();
            for (int i = 0; i < Rows; i++)
            {
                for (int j = 0; j < Columns; j++)
                {
                    data[i][j] = (float)random.Next(maxValue) / 8;
                }
            }
        }

        public void SaveAsText(string filePath)
        {
            using (StreamWriter sw = new StreamWriter(filePath, false))
            {
                SaveMatrixText(sw);
            }
        }

        public void SaveAsTextAndCompress(string filePath)
        {
            using (GZipStream cs = new GZipStream(File.OpenWrite(filePath), CompressionMode.Compress))
            using (StreamWriter sw = new StreamWriter(cs))
            {
                SaveMatrixText(sw);
            }
        }

        private void SaveMatrixText(TextWriter sw)
        {
            sw.WriteLine(String.Format("{0} {1}", Rows, Columns));
            for (int i = 0; i < Rows; i++)
            {
                for (int j = 0; j < Columns - 1; j++)
                {
                    sw.Write(data[i][j].ToString(CultureInfo.InvariantCulture));
                    sw.Write(" ");
                }
                sw.Write(data[i][columns - 1].ToString(CultureInfo.InvariantCulture));
                sw.WriteLine();
            }
        }


        internal void SaveAsBinaryDataCompress(string filePath)
        {
            using (GZipStream cs = new GZipStream(File.OpenWrite(filePath), CompressionMode.Compress))
            using (BinaryWriter sw = new BinaryWriter(cs))
            {
                SaveMatrixBinary(sw);
            }
         }

        public void SaveAsBinaryData(string filePath)
        {
            using (BinaryWriter sw = new BinaryWriter(File.Open(filePath, FileMode.Create)))
            {
                SaveMatrixBinary(sw);
            }
        }

        
        private void SaveMatrixBinary(BinaryWriter sw)
        {
            sw.Write(Rows);
            sw.Write(Columns);
            for (int i = 0; i < Rows; i++)
            {
                for (int j = 0; j < Columns; j++)
                {
                    sw.Write(data[i][j]);
                }
            }
        }

        public static Matrix LoadMatrixFromText(string filePath)
        {
            using (StreamReader sr = new StreamReader(File.Open(filePath, FileMode.Open)))
            {
                string[] info = sr.ReadLine().Split(' ');
                Matrix matrix = new Matrix(int.Parse(info[0]), Convert.ToInt32(info[1]));
                for (int i = 0; i < matrix.Rows; i++)
                {
                    string[] line = sr.ReadLine().Split(' ');
                    for (int j = 0; j < matrix.Columns; j++)
                    {
                        matrix.Data[i][j] = Convert.ToSingle(line[j], CultureInfo.InvariantCulture);
                    }
                }
                return matrix;
            }
        }

        public static Matrix LoadMatrixFromBinaryData(string filePath)
        {
            using (BinaryReader sr = new BinaryReader(File.Open(filePath, FileMode.Open)))
            {
                return LoatMatrixBinary(sr);
            }
        }

        private static Matrix LoatMatrixBinary(BinaryReader sr)
        {
            int rows = sr.ReadInt32();
            int columns = sr.ReadInt32();
            Matrix matrix = new Matrix(rows, columns);
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    matrix.Data[i][j] = sr.ReadSingle();
                }
            }
            return matrix;
        }

        public static bool Compare(Matrix m1, Matrix m2)
        {
            if (m1.Rows != m2.Rows)
            {
                return false;
            }
            if (m1.Columns != m2.Columns)
            {
                return false;
            }
            for (int i = 0; i < m1.Rows; i++)
            {
                for (int j = 0; j < m1.Columns; j++)
                {
                    if (m1.Data[i][j] != m2.Data[i][j])
                    {
                        return false;
                    }
                }
            }
            return true;
        }


    }
}
