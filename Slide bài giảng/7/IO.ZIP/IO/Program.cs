using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Text;
using ca5.Properties;

namespace ca5
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = Settings.Default.Rows;
            int b = Settings.Default.Columns;

            Matrix matrix = new Matrix(
                    int.Parse(ConfigurationManager.AppSettings["rows"]),
                    int.Parse(ConfigurationManager.AppSettings["columns"])
                );

            Stopwatch sw = new Stopwatch(); // Mereni casu
            matrix.RandomInit(20000);

            sw.Start();
            matrix.SaveAsText(@"f:\pjii\test.txt");
            Console.WriteLine(sw.ElapsedMilliseconds);

            sw.Reset();
            sw.Start();
            matrix.SaveAsTextAndCompress(@"f:\pjii\test.txt.zip");
            Console.WriteLine(sw.ElapsedMilliseconds);

            sw.Reset();
            sw.Start();
            matrix.SaveAsBinaryData(@"f:\pjii\test.bin");
            Console.WriteLine(sw.ElapsedMilliseconds);

            sw.Reset();
            sw.Start();
            matrix.SaveAsBinaryDataCompress(@"f:\pjii\test.bin.zip");
            Console.WriteLine(sw.ElapsedMilliseconds);

            sw.Reset();
            sw.Start();
            Matrix matrixText = Matrix.LoadMatrixFromText(@"f:\pjii\test.txt");
            Console.WriteLine(sw.ElapsedMilliseconds);

            sw.Reset();
            sw.Start();
            Matrix matrixBinary = Matrix.LoadMatrixFromBinaryData(@"f:\pjii\test.bin");
            Console.WriteLine(sw.ElapsedMilliseconds);
         
            //Console.WriteLine("Original to text is {0}", Matrix.Compare(matrix, matrixText));
            //Console.WriteLine("Original to binary is {0}", Matrix.Compare(matrix, matrixBinary));
          }
    }
}
