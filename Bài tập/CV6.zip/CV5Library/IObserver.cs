﻿namespace CV5Library
{
    public interface IObserver
    {
        void Update(Subject subject);
    }
}
