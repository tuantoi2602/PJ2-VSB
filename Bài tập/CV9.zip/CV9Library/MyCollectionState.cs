﻿namespace CV9Library
{
    public enum MyCollectionState
    {
        Empty,
        Full,
        PartiallyFull
    }
}
