﻿namespace CV1Library
{
    public class Greeter
    {
        public string SayHello(string name)
        {
            return "Hello, " + name + "!";
        }
    }
}
