﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTimeTest2
{
    class IPAddress
    {
        private string ip;
        private string mask;


        public enum Access { Allow, Deny };
        public Access AccessProperty { get; set; }

        public IPAddress(string ipi, string maski)
        {
            ip = ipi;
            mask = maski;
        }

        public bool IsInNetwork(string ipadres)
        {
            string[] samplesOfAddress = ipadres.Split('.');
            string[] samplesOfMask = mask.Split('.');
            string[] samplesOfIP = ip.Split('.');
            bool res = true;


            for (int i = 0; i < 4; i++)
            {
                if (samplesOfMask[i] == "255")
                {
                    if(samplesOfIP[i]== samplesOfAddress[i])
                    {
                        continue;
                    }
                    else
                    {
                        res = false;
                        break;
                    }
                }
                else
                {
                    break;
                }
            }



            return res;
        }

    }
}
