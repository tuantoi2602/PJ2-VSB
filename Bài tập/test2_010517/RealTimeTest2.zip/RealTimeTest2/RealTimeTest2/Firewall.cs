﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTimeTest2
{
    class Firewall
    {

        public IList<Rule> Rules;


        public Firewall(String path)
        {

            StreamReader sr = new StreamReader(path);
            while (!sr.EndOfStream)
            {
                //Console.WriteLine(sr.ReadLine());
                string help = sr.ReadLine();
                help.Replace(" ", "");
               // Console.WriteLine(help);
                string[] dataStrings = help.Split('-');
               // Console.WriteLine(dataStrings[2]);

                if (dataStrings[2] == "A")
                {
                    this.Rules.Add(new Rule(new IPAddress(dataStrings[0], dataStrings[1]), IPAddress.Access.Allow));
                }
                else if (dataStrings[2] == "N")
                {
                    this.Rules.Add(new Rule(new IPAddress(dataStrings[0], dataStrings[1]), IPAddress.Access.Deny));
                }                
            }

        }

        public bool Test(String ip)
        {
            bool res=false;      
            foreach (Rule r in this.Rules)
            {
                Console.WriteLine(r.Network);
               
                if (r.Network.IsInNetwork(ip))
                {
                    res = true;
                    Console.WriteLine("True");
                    break;
                }
            }

            return res;
        }
    }
}
