﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTimeTest2
{
    class Rule
    {
        private IPAddress network;
        private IPAddress.Access type;

        public IPAddress Network
        {
            get
            {
                return network;
            }
            set
            {
                network = value;
            }
        }


        public IPAddress.Access Type
        {
            get
            {
                return type;
            }
            set
            {
                type = value;
            }
        }


        public Rule(IPAddress ip, IPAddress.Access x)
        {
            Network = ip;
            Type = x;
        }

        

    }
}
