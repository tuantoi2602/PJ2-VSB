﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTimeTest2
{
    class Program
    {
        static void Main(string[] args)
        {
             IPAddress test = new IPAddress("192.168.0.1", "255.255.0.0");
             if (test.IsInNetwork("192.168.100.11"))
             {
                 Console.WriteLine("True");
             }
            Console.ReadKey();
            Firewall firewall = new Firewall("test.txt");
            foreach (Rule r in firewall.Rules)
            {

                Console.WriteLine(r.Network + " " + r.Type);
            }
            //Console.WriteLine(firewall.Test("192.168.10.100"));
            //Console.WriteLine(firewall.Test("192.168.11.100"));

        }
    }
}
