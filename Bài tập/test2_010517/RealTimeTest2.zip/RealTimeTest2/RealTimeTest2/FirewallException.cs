﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTimeTest2
{
    [Serializable]
    class FirewallException:Exception
    {
        public IPAddress ip { get; set; }
        public IPAddress IP
        {
            get
            {
                return ip;
            }
            set
            {
                ip = value;
            }
        }

        public FirewallException(IPAddress IP, string message) 
            : base(message)
        {
            ip = IP;
        }
    }
}
