﻿namespace CV4Library
{
    public enum MyCollectionState
    {
        Empty,
        Full,
        PartiallyFull
    }
}
