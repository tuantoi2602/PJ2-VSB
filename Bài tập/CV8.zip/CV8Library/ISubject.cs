﻿namespace CV8Library
{
    public interface ISubject
    {
        void Notify();
    }
}
