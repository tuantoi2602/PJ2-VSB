﻿using System;

namespace CV8Library
{
    public class InvoiceEventArgs : EventArgs
    {
        public string Message { get; set; }
    }
}
